import ij.*;
import ij.gui.*;
import ij.measure.*;
import ij.plugin.*;
import ij.process.*;

public class FRAP_Analysis implements PlugIn {
    public void run(String arg) {
        ImagePlus imp = IJ.getImage();
        if (imp == null) {
            IJ.noImage();
            return;
        }

        RoiManager roiManager = RoiManager.getInstance();
        if (roiManager == null) {
            roiManager = new RoiManager();
        }

        GenericDialog gd = new GenericDialog("FRAP Analysis");
        gd.addNumericField("Bleach Frame:", 1, 0);
        gd.showDialog();
        if (gd.wasCanceled()) {
            return;
        }

        int bleachFrame = (int) gd.getNextNumber();

        if (bleachFrame < 1 || bleachFrame > imp.getNFrames()) {
            IJ.showMessage("Invalid bleach frame.");
            return;
        }

        roiManager.runCommand(imp, "Show All");
        Roi[] rois = roiManager.getRoisAsArray();
        if (rois.length == 0) {
            IJ.showMessage("No ROIs found.");
            return;
        }

        ResultsTable rt = new ResultsTable();
        for (int i = 0; i < rois.length; i++) {
            imp.setRoi(rois[i]);
            ImageStatistics stats = imp.getStatistics(Measurements.MEAN, bleachFrame);
            double initialIntensity = stats.mean;
            double[] intensityValues = new double[imp.getNFrames()];

            for (int t = 0; t < imp.getNFrames(); t++) {
                imp.setC(t + 1);
                stats = imp.getStatistics(Measurements.MEAN);
                intensityValues[t] = (stats.mean - initialIntensity) / initialIntensity;
            }

            rt.incrementCounter();
            rt.addValue("ROI", i + 1);
            rt.addResults(stats, initialIntensity);
            rt.addColumn("Time", imp.getFrameRate(), intensityValues);
        }

        roiManager.runCommand("Show None");
        rt.show("FRAP Results");
    }
}

